void comms_init();
